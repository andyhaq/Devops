HyperCam 2 Readme.txt file

HyperCam captures the action from your Windows screen and saves 
it to AVI (Audio-Video Interleaved) movie file.  Your machine may run in 
any color mode.  Sound from your system microphone is also recorded.  


Installation:
-------------
To install HyperCam, please run HC2Setup.exe program.

Program Status:
---------------
HyperCam software and trademark are owned by Hyperionics Technology, LLC
and are protected by United States copyright laws and international treaty
provisions. Hyperionics now grants a free, world-wide license to use
HyperCam versions 2.xx free of charge in both private home use and in any
corporations and organizations.  

Distribution:
-------------
Distribution is permitted provided you follow these instructions: You are 
free to make copies of the distribution archive and pass it 
along to others for their evaluation provided that no modifications or 
additions are made to the software, its documentation, or any associated 
files, and it is not bundled in a distribution of any other software.  

Usage:
------
Select the area you want to capture, then select Start Rec.  button or 
press a hot key.  You may press the same hot key to finish.  There is also 
a "Pause/Resume" hot key and button.  You may pan (move the recorded area) 
by holding e.g.  Shift key and moving the mouse.  Please click on each tab 
in the HyperCam dialog and try to figure out what to do, or read the 
detailed help file.

Updates:
--------
For newer versions of HyperCam please check Hyperionics WEB at:

	http://www.hyperionics.com/

or email us at info@hyperionics.com

Thank you for using HyperCam!


